<?php

namespace HR\Http\Controllers;

use Illuminate\Http\Request;

class ThrottleController extends Controller
{
    //
}
