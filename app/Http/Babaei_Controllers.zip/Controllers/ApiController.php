<?php

namespace HR\Http\Controllers;

use HR\UserProfile;
use Illuminate\Http\JsonResponse;
use Storage;
use Response;
use HR\myFuncs;

use Barryvdh\Snappy\Facades\SnappyPdf;
use Carbon\Carbon;
use HR\Apply;
use HR\City;
use HR\Company;
use HR\Industry;
use HR\Job;
use HR\JobDepartment;
use HR\JobGeneralMerites;
use HR\JobOrganizationalCategory;
use HR\JobPost;
use HR\JobProfessionalMerites;
use HR\JobQuestions;
use HR\myDate;
use HR\Province;
use HR\RejectReasons;
use HR\Resume;
use HR\ResumeContractType;
use HR\Slider;
use HR\SMS;
use HR\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;
use p3ym4n\JDate\JDate;


class ApiController extends Controller
{
    public function __construct()
    {
        /**
         * Degrees DB table replace with config('app.enum_degrees')
         * 97-11-17
         * @author M.Mahdavi Kia
         * @global $this->degrees_array
         */
        $this->degrees_array = array();
        $Degrees = DB::table('degrees')->get();
        foreach($Degrees as $deg){
            $this->degrees_array[$deg->id] = $deg->name;
        }
    }

    public function get_job_posts()
    {
        return JobPost::where('data_id',0)->get();
    }

    public function apply_status(Request $request){
        $post = $request->all();
        $apply_arr = config('app.enum_apply_status');
        $apply_id = $post['apply_id'];
        $status = intval($post['status']);
        $applies_table = DB::table('applies')->where('id','=',$apply_id)->get()->last();
        if(isset($applies_table->status)){

            $result = DB::table('applies')
                ->where('id', $apply_id)
                ->update(['status'=>$status]);
            if($result=="1"){
                $a = ['status'=>1,'message'=>'successful'];
            }else{
                $a = ['status'=>0,'message'=>'error or duplicate update'];
            }
            echo json_encode($a);exit;

        }else{
            $a = ['status'=>0,'message'=>'apply_id not found'];
            echo json_encode($a);exit;
        }
    }

    public function get_institute_structure()
    {

        $arr = config('app.enum_institute_structure');
        $arr2 = [];
        $a=0;
        foreach($arr as $as){
            $a++;
            $arr2[]=["id"=>$a,"name"=>$as];
        }
        $j =json_encode($arr2);
        echo $j;
        exit;
    }

    public function get_job_departments()
    {
        return JobDepartment::where('data_id',0)->get();
    }

    public function get_job_organizational_category()
    {
        return JobOrganizationalCategory::all();
    }

    public function get_job_general_skills()
    {
        return JobGeneralMerites::all();
    }

    public function get_job_special_skills()
    {
        $jobs_professional_merites = array_unique(DB::table('job_has_professional_merites')
            ->pluck('professional_merites_id')->toArray());
        $job_professional_merites = JobProfessionalMerites::whereIn('id', $jobs_professional_merites)->get();

        return $job_professional_merites;
    }

    public function get_cities()
    {
        $result = [];

        foreach (City::all() as $item)
            $result[] = (object)[
                'id' => $item->id,
                'name' => $item->province->name . ' - ' . $item->name
            ];

        return $result;
    }

    public function get_provinces()
    {
        return Province::all();
    }

    public function get_industries()
    {
        return Industry::all();
    }

    public function get_min_education()
    {
        $enum_degrees = $this->degrees_array;
        $result = [];
        foreach ($enum_degrees as $key => $item) {
            $result[] = (object)[
                'id' => $key,
                'name' => $item
            ];
        }

        return $result;
    }

    public function get_cooperation_types()
    {
        return ResumeContractType::all();
    }

    public function get_job_exp()
    {
        $enum_exp_needed = array_values(config('app.enum_exp_needed'));
        $result = [];
        $i = 1;
        foreach ($enum_exp_needed as $item) {
            $result[] = (object)[
                'id' => $i++,
                'name' => $item
            ];
        }

        return $result;
    }

    public function get_companies()
    {
        return Company::all(['id', 'name']);
    }

    /*public function post_create_job(Request $request)
    {
        $rules = array(
            'apply_limit' => 'sometimes|nullable|integer',
            'alias' => 'required|string',
            'pin_status' => 'required|integer|between:0,1',
            //'department' => 'required|integer|exists:job_departments,id',
            'min_education' => 'required|integer|between:0,10',
            'post' => 'required|string|max:256',
            'mobile' => 'required|regex:/[0-9]{11}/u',
            'main_responsibilities' => 'required|string',
            'cooperation_type' => 'required|integer|min:1',
            'gender' => 'required|integer|between:1,3',
            'company' => 'required|integer|exists:companies,id',
            'city_id' => 'required|array|min:1',
            'industry_id' => 'required|integer|exists:industries,id',
            'status' => 'required|integer|between:1,3',
            'images' => 'nullable|string',
            'jobExp' => 'nullable|string',
            'field' => 'nullable|string',
            'goal_or_mission' => 'required|string',
            'general_skill' => 'required|array|min:1|max:100',
            'general_skill.*.name' => 'required|string|min:1|max:256',
            'general_skill.*.value' => 'required|int|between:1,4',
            'special_skill' => 'required|array|min:1|max:100',
            'special_skill.*.name' => 'required|string|min:1|max:256',
            'special_skill.*.value' => 'required|int|between:1,4',
            'questions' => 'nullable|array',
            'questions.*.question' => 'nullable|string|max:255',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }
        $company_flag = Company::where('id',$request['company'])->first()->flag;

        $job = new Job();
        if($company_flag == 0) {
            $job->title = $request['post'];

            $job->alias = str_replace(array(' ', '/'), array('-', '-'), $request['alias']);
            $i = 1;
            $tmp_alias = $job->alias;
            if (Job::where('alias', $job->alias)->count()) {

                while (Job::where('alias', $tmp_alias)->count()) {
                    $i++;
                    $tmp_alias = $job->alias . '-' . $i;
                }
                $job->alias = $tmp_alias;
            }
            $job->alias = strtolower($job->alias);
            $job->pin_status = $request['pin_status'];
            $job->department_id = $request['department'];
            $job->min_education = $request['min_education'];
            $job->company_id = $request['company'];
            $job->cooperation_type = $request['cooperation_type'];
            $job->gender = $request['gender'];
            $job->goal_or_mission = $request['goal_or_mission'];
            $job->main_responsibilities = $request['main_responsibilities'];
            $job->job_other_features = $request['other_features'];
            $job->status = $request['status'];
            $job->industry_id = $request['industry_id'];
            $job->industry_id = $request['industry_id'];
            $job->jobExp = $request['jobExp'];
            $job->field = $request['field'];
            $job->expire_date = Carbon::now()->timezone('Asia/Tehran')->addDay(30);
            $job->apply_limit = $request['apply_limit'];

            // M.M.Kia
            // 1398/01/18
            $job->PortalAddress = $request['PortalAdrs'];
            $job->ItemId = $request['ItemID'];
            $job->PortalStatus = $request['status'];

            $mobile = $request['mobile'];
            $user = User::where('mobile', $mobile)->get()->first();

            if (
                !$user ||
                (!in_array($request['company'], $user->company->pluck('id')->toArray()) && !auth()->user()->hasAnyRole('برنامه نویس|سوپرادمین'))
            )
                return ['ادمین موردنظر یافت نشد یا مربوط به شرکت انتخاب شده نمی باشد.'];

            $job->created_by = $user->id;
            $job->modified_by = $user->id;

            if (JobPost::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $request['post']))->count() == 0) {
                JobPost::create(['name' => $request['post']]);
                $post_id = JobPost::where('name', $request['post'])->first()->id;
            } else {
                $post_id = JobPost::where('name', $request['post'])->first()->id;
            }
            $job->post_id = $post_id;
        }
        else
        {
            $job->title = $request['api_post_name'];

            $job->alias = str_replace(array(' ', '/'), array('-', '-'), $request['alias']);
            $i = 1;
            $tmp_alias = $job->alias;
            if (Job::where('alias', $job->alias)->count()) {

                while (Job::where('alias', $tmp_alias)->count()) {
                    $i++;
                    $tmp_alias = $job->alias . '-' . $i;
                }
                $job->alias = $tmp_alias;
            }
            $job->alias = strtolower($job->alias);
            $job->pin_status = $request['pin_status'];
           // $job->department_id = $request['department'];
            $job->min_education = $request['min_education'];
            $job->company_id = $request['company'];
            $job->cooperation_type = $request['cooperation_type'];
            $job->gender = $request['gender'];
            $job->goal_or_mission = $request['goal_or_mission'];
            $job->main_responsibilities = $request['main_responsibilities'];
            $job->job_other_features = $request['other_features'];
            $job->status = $request['status'];
            $job->industry_id = $request['industry_id'];
            $job->industry_id = $request['industry_id'];
            $job->jobExp = $request['jobExp'];
            $job->field = $request['field'];
            $job->expire_date = Carbon::now()->timezone('Asia/Tehran')->addDay(30);
            $job->apply_limit = $request['apply_limit'];

            // M.M.Kia
            // 1398/01/18
            $job->PortalAddress = $request['PortalAdrs'];
            $job->ItemId = $request['ItemID'];
            $job->PortalStatus = $request['status'];
            $job->api_post_id  = $request['api_post_id'];
            $job->api_serial_number_post  = $request['api_serial_number_post'];
            $job->api_department_id  = $request['api_department_id'];

            $api_dep_name = $request['api_department_name'];
            $api_post_name = $request['api_post_name'];

            $mobile = $request['mobile'];
            $user = User::where('mobile', $mobile)->get()->first();

            if (
                !$user ||
                (!in_array($request['company'], $user->company->pluck('id')->toArray()) && !auth()->user()->hasAnyRole('برنامه نویس|سوپرادمین'))
            )
                return ['ادمین موردنظر یافت نشد یا مربوط به شرکت انتخاب شده نمی باشد.'];

            $job->created_by = $user->id;
            $job->modified_by = $user->id;

            if (JobDepartment::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $request['api_department_name']))->count() == 0) {
                JobDepartment::create(['name' => $request['api_department_name'], 'data_id' => $request['api_department_id'], 'company_id' =>$request['company'] ]);
                $job->department_id  = JobDepartment::where('name' , $request['api_department_name'])->first()->id;

            }


            if (JobPost::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $request['api_post_name']))->count() == 0) {
                $department_id  = JobDepartment::where('name' , $request['api_department_name'])->first()->id;

                JobPost::create(['name' => $request['api_post_name'],'data_id'=> $request['api_post_id'],'department_id'=>$department_id]);

                $post_id = JobPost::where('name', $request['api_post_name'])->first()->id;
            } else {
                $post_id = JobPost::where('name', $request['api_post_name'])->first()->id;
            }
            $job->post_id = $post_id;
            $job->post_id = $post_id;
        }

        $job->save();

        #extra questions
        if (isset($request['questions'])) {
            foreach ($request['questions'] as $item) {
                $q = new JobQuestions();
                $q->question = $item['question'];
                $q->job_id = $job->id;
                $q->save();
            }
        }
        #end of extra questions

        foreach ($request['city_id'] as $item) {
            $job->cities()->attach($item);
        }


        if (isset($request['images']) && !empty($request['images'])) {
            $images = explode(',', $request['images']);
            $images = array_filter($images);
            foreach ($images as $image) {
                $img = new Slider();
                $img->model_name = 'Job';
                $img->model_id = $job->id;
                $img->url = $image;
                $img->save();
            }
        }

        # start of job_general_merites
        if($company_flag == 0) {
            $general_skill = $request['general_skill'];
            foreach ($general_skill as $item) {

                $merit = JobGeneralMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
                if (!$merit) {
                    JobGeneralMerites::create(['name' => $item['name']]);
                    $merit = JobGeneralMerites::where('name', $item['name'])->first();
                }
                $job->job_general_merites()->attach([$merit->id => ['value' => $item['value']]]);
            }
            # end of job_general_merites


            # start of job_general_merites
            $special_skill = $request['special_skill'];
            foreach ($special_skill as $item) {
                $merit = JobProfessionalMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
                if (!$merit) {
                    JobProfessionalMerites::create(['name' => $item['name']]);
                    $merit = JobProfessionalMerites::where('name', $item['name'])->first();
                }
                $job->job_professional_merites()->attach([$merit->id => ['value' => $item['value']]]);
            }
            # end of job_general_merites
        }
        else
        {
            $general_skill = $request['general_skill'];
            foreach ($general_skill as $item) {

                $merit = JobGeneralMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
                if (!$merit) {
                    JobGeneralMerites::create(['name' => $item['name'], 'general_data_id' => $item['id']]);
                    $merit = JobGeneralMerites::where('name', $item['name'])->first();
                }
                $job->job_general_merites()->attach([$merit->id => ['value' => $item['value']]]);
            }
            # end of job_general_merites


            # start of job_general_merites
            $special_skill = $request['special_skill'];
            foreach ($special_skill as $item) {
                $merit = JobProfessionalMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
                if (!$merit) {
                    JobProfessionalMerites::create(['name' => $item['name'], 'professional_data_id' => $item['id']]);
                    $merit = JobProfessionalMerites::where('name', $item['name'])->first();
                }
                $job->job_professional_merites()->attach([$merit->id => ['value' => $item['value']]]);
            }
        }

        return $job;
    }*/
    
        public function post_create_job_old(Request $request)
    {
        $rules = array(
            'apply_limit' => 'sometimes|nullable|integer',
            'alias' => 'required|string',
            'pin_status' => 'required|integer|between:0,1',
            'department' => 'required|integer|exists:job_departments,id',
            'min_education' => 'required|integer|between:0,10',
            'post' => 'required|string|max:256',
            'mobile' => 'required|regex:/[0-9]{11}/u',
            'main_responsibilities' => 'required|string',
            'cooperation_type' => 'required|integer|min:1',
            'gender' => 'required|integer|between:1,3',
            'company' => 'required|integer|exists:companies,id',
            'city_id' => 'required|array|min:1',
            'industry_id' => 'required|integer|exists:industries,id',
            'status' => 'required|integer|between:1,3',
            'images' => 'nullable|string',
            'jobExp' => 'nullable|string',
            'field' => 'nullable|string',
            'goal_or_mission' => 'required|string',
            'general_skill' => 'required|array|min:1|max:100',
            'general_skill.*.name' => 'required|string|min:1|max:256',
            'general_skill.*.value' => 'required|int|between:1,4',
            'special_skill' => 'required|array|min:1|max:100',
            'special_skill.*.name' => 'required|string|min:1|max:256',
            'special_skill.*.value' => 'required|int|between:1,4',
            'questions' => 'nullable|array',
            'questions.*.question' => 'nullable|string|max:255',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }

        $job = new Job();
        $job->title = $request['post'];

        $job->alias = str_replace(array(' ', '/'), array('-', '-'), $request['alias']);
        $i = 1;
        $tmp_alias = $job->alias;
        if (Job::where('alias', $job->alias)->count()) {

            while (Job::where('alias', $tmp_alias)->count()) {
                $i++;
                $tmp_alias = $job->alias . '-' . $i;
            }
            $job->alias = $tmp_alias;
        }
        $job->alias = strtolower($job->alias);
        $job->pin_status = $request['pin_status'];
        $job->department_id = $request['department'];
        $job->min_education = $request['min_education'];
        $job->company_id = $request['company'];
        $job->cooperation_type = $request['cooperation_type'];
        $job->gender = $request['gender'];
        $job->goal_or_mission = $request['goal_or_mission'];
        $job->main_responsibilities = $request['main_responsibilities'];
        $job->job_other_features = $request['other_features'];
        $job->status = $request['status'];
        $job->industry_id = $request['industry_id'];
        $job->industry_id = $request['industry_id'];
        $job->jobExp = $request['jobExp'];
        $job->field = $request['field'];
        $job->expire_date = Carbon::now()->timezone('Asia/Tehran')->addDay(30);
        $job->apply_limit = $request['apply_limit'];

        // M.M.Kia
        // 1398/01/18
        $job->PortalAddress = $request['PortalAdrs'];
        $job->ItemId = $request['ItemID'];
        $job->PortalStatus = $request['status'];

        $mobile = $request['mobile'];
        $user = User::where('mobile', $mobile)->get()->first();

        if (
            !$user ||
            (!in_array($request['company'], $user->company->pluck('id')->toArray()) && !$user->hasAnyRole('برنامه نویس|سوپرادمین'))
        )
            return ['ادمین موردنظر یافت نشد یا مربوط به شرکت انتخاب شده نمی باشد.'];

        $job->created_by = $user->id;
        $job->modified_by = $user->id;

        if (JobPost::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $request['post']))->count() == 0) {
            JobPost::create(['name' => $request['post']]);
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        } else {
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        }
        $job->post_id = $post_id;

        $job->save();

        #extra questions
        if (isset($request['questions'])) {
            foreach ($request['questions'] as $item) {
                $q = new JobQuestions();
                $q->question = $item['question'];
                $q->job_id = $job->id;
                $q->save();
            }
        }
        #end of extra questions

        foreach ($request['city_id'] as $item) {
            $job->cities()->attach($item);
        }


        if (isset($request['images']) && !empty($request['images'])) {
            $images = explode(',', $request['images']);
            $images = array_filter($images);
            foreach ($images as $image) {
                $img = new Slider();
                $img->model_name = 'Job';
                $img->model_id = $job->id;
                $img->url = $image;
                $img->save();
            }
        }

        # start of job_general_merites
        $general_skill = $request['general_skill'];
        foreach ($general_skill as $item) {

            $merit = JobGeneralMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobGeneralMerites::create(['name' => $item['name']]);
                $merit = JobGeneralMerites::where('name', $item['name'])->first();
            }
            $job->job_general_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites


        # start of job_general_merites
        $special_skill = $request['special_skill'];
        foreach ($special_skill as $item) {
            $merit = JobProfessionalMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobProfessionalMerites::create(['name' => $item['name']]);
                $merit = JobProfessionalMerites::where('name', $item['name'])->first();
            }
            $job->job_professional_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites

        return $job;
    }
    public function post_create_job(Request $request)
    {
        \Illuminate\Support\Facades\Storage::append('api_postcreatejob_error.txt', "\n".date('Y-m-d H:m').' ===> '.json_encode($request->all()));
        $rules = array(
            'apply_limit' => 'sometimes|nullable|integer',
            'alias' => 'required|string',
            'pin_status' => 'required|integer|between:0,1',
            'department' => 'required|integer|exists:job_departments,id',
            'min_education' => 'required|integer|between:0,10',
            'post' => 'required|string|max:256',
            'mobile' => 'required|regex:/[0-9]{11}/u',
            'main_responsibilities' => 'required|string',
            'cooperation_type' => 'required|integer|min:1',
            'gender' => 'required|integer|between:1,3',
            'company' => 'required|integer|exists:companies,id',
            'city_id' => 'required|array|min:1',
            'industry_id' => 'required|integer|exists:industries,id',
            'status' => 'required|integer|between:1,3',
            'images' => 'nullable|string',
            'jobExp' => 'nullable|string',
            'field' => 'nullable|string',
            'goal_or_mission' => 'required|string',
            'general_skill' => 'required|array|min:1|max:100',
            'general_skill.*.name' => 'required|string|min:1|max:256',
            'general_skill.*.value' => 'required|int|between:1,4',
            'special_skill' => 'required|array|min:1|max:100',
            'special_skill.*.name' => 'required|string|min:1|max:256',
            'special_skill.*.value' => 'required|int|between:1,4',
            'questions' => 'nullable|array',
            'questions.*.question' => 'nullable|string|max:255',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }

        $job = new Job();
        $job->title = $request['post'];

        $job->alias = str_replace(array(' ', '/'), array('-', '-'), $request['alias']);
        $i = 1;
        $tmp_alias = $job->alias;
        if (Job::where('alias', $job->alias)->count()) {

            while (Job::where('alias', $tmp_alias)->count()) {
                $i++;
                $tmp_alias = $job->alias . '-' . $i;
            }
            $job->alias = $tmp_alias;
        }
        $job->alias = strtolower($job->alias);
        $job->pin_status = $request['pin_status'];
        $job->department_id = $request['department'];
        $job->min_education = $request['min_education'];
        $job->company_id = $request['company'];
        $job->cooperation_type = $request['cooperation_type'];
        $job->gender = $request['gender'];
        $job->goal_or_mission = $request['goal_or_mission'];
        $job->main_responsibilities = $request['main_responsibilities'];
        $job->job_other_features = $request['other_features'];
        $job->status = $request['status'];
        $job->industry_id = $request['industry_id'];
        $job->industry_id = $request['industry_id'];
        $job->jobExp = $request['jobExp'];
        $job->field = $request['field'];
        $job->expire_date = Carbon::now()->timezone('Asia/Tehran')->addDay(30);
        $job->apply_limit = $request['apply_limit'];

        // M.M.Kia
        // 1398/01/18
        $job->PortalAddress = $request['PortalAdrs'];
        $job->ItemId = $request['ItemID'];
        $job->PortalStatus = $request['status'];

        $mobile = $request['mobile'];
        $user = User::where('mobile', $mobile)->get()->first();

        if (
            !$user ||
            (!in_array($request['company'], $user->company->pluck('id')->toArray()) && !$user->hasAnyRole('برنامه نویس|سوپرادمین'))
        )
            return ['ادمین موردنظر یافت نشد یا مربوط به شرکت انتخاب شده نمی باشد.'];
  if (Job::where('ItemId', $request['ItemID'])->count())
            return ['آگهی تکراری است'];

        $job->created_by = $user->id;
        $job->modified_by = $user->id;

        if (JobPost::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $request['post']))->count() == 0) {
            JobPost::create(['name' => $request['post']]);
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        } else {
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        }
        $job->post_id = $post_id;
        $company = Company::where('id',$request['company'])->first();

        $company_name =  str_replace(array(' ', '/'), array('-', '-'), $company->name);
        $post_title_alias = $request['post'];
        $post_title_alias = str_replace(array(' ', '/'), array('-', '-'),$post_title_alias);
        $created = date('Y-m-d');
        
        $persian_alias = $company_name.'_'.$post_title_alias.'_'.$created;
        $job->persian_alias = $persian_alias;

        $job->save();

        #extra questions
        if (isset($request['questions'])) {
            foreach ($request['questions'] as $item) {
                $q = new JobQuestions();
                $q->question = $item['question'];
                $q->job_id = $job->id;
                $q->save();
            }
        }
        #end of extra questions

        foreach ($request['city_id'] as $item) {
            $job->cities()->attach($item);
        }


        if (isset($request['images']) && !empty($request['images'])) {
            $images = explode(',', $request['images']);
            $images = array_filter($images);
            foreach ($images as $image) {
                $img = new Slider();
                $img->model_name = 'Job';
                $img->model_id = $job->id;
                $img->url = $image;
                $img->save();
            }
        }

        # start of job_general_merites
        $general_skill = $request['general_skill'];
        foreach ($general_skill as $item) {

            $merit = JobGeneralMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobGeneralMerites::create(['name' => $item['name']]);
                $merit = JobGeneralMerites::where('name', $item['name'])->first();
            }
            $job->job_general_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites


        # start of job_general_merites
        $special_skill = $request['special_skill'];
        foreach ($special_skill as $item) {
            $merit = JobProfessionalMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobProfessionalMerites::create(['name' => $item['name']]);
                $merit = JobProfessionalMerites::where('name', $item['name'])->first();
            }
            $job->job_professional_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites

        return $job;
    }


    public function post_edit_job(Request $request)
    {
        $rules = array(
            'id' => 'required|integer|exists:jobs,id',
            'apply_limit' => 'sometimes|nullable|integer',
            'alias' => 'required|string',
            'pin_status' => 'required|integer|between:0,1',
            'department' => 'required|integer|exists:job_departments,id',
            'min_education' => 'required|integer|between:0,10',
            'post' => 'required|string|max:256',
            'mobile' => 'required|regex:/[0-9]{11}/u',
            'main_responsibilities' => 'required|string',
            'cooperation_type' => 'required|integer|min:1',
            'gender' => 'required|integer|between:1,3',
            'company' => 'required|integer|exists:companies,id',
            'city_id' => 'required|array|min:1',
            'industry_id' => 'required|integer|exists:industries,id',
            'status' => 'required|integer|between:1,3',
            'images' => 'nullable|string',
            'jobExp' => 'nullable|string',
            'field' => 'nullable|string',
            'goal_or_mission' => 'required|string',
            'general_skill' => 'required|array|min:1|max:100',
            'general_skill.*.name' => 'required|string|min:1|max:256',
            'general_skill.*.value' => 'required|int|between:1,4',
            'special_skill' => 'required|array|min:1|max:100',
            'special_skill.*.name' => 'required|string|min:1|max:256',
            'special_skill.*.value' => 'required|int|between:1,4',
            'questions' => 'sometimes|required|array|min:1|max:100',
            'questions.*.question' => 'sometimes|required|string|max:255',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }


        $job = Job::FindOrFail($request['id']);

        $job->title = $request['post'];
        if ($request['alias'] != $job->alias) {
            $job->alias = str_replace(' ', '-', $request['alias']);
            if (Job::where('alias', $job->alias)->count())
                $job->alias .= '-' . (string)Job::where('alias', $job->alias)->count();
            $job->alias = strtolower($job->alias);
        }
        $job->pin_status = $request['pin_status'];
        $job->department_id = $request['department'];
        $job->min_education = $request['min_education'];
        $job->company_id = $request['company'];
        $job->cooperation_type = $request['cooperation_type'];
        $job->gender = $request['gender'];
        $job->goal_or_mission = $request['goal_or_mission'];
        $job->main_responsibilities = $request['main_responsibilities'];
        $job->job_other_features = $request['other_features'];
        $job->status = $request['status'];
        $job->industry_id = $request['industry_id'];
        $job->industry_id = $request['industry_id'];
        $job->jobExp = $request['jobExp'];
        $job->field = $request['field'];
        $job->expire_date = Carbon::now()->timezone('Asia/Tehran')->addDay(30);
        $job->apply_limit = $request['apply_limit'];

        // M.M.Kia
        // 1398/01/18
        $job->PortalAddress = $request['PortalAdrs'];
        $job->ItemId = $request['ItemID'];
        $job->PortalStatus = $request['status'];

        $mobile = $request['mobile'];
        $user = User::where('mobile', $mobile)->get()->first();

        if (
            !$user ||
            (!in_array($request['company'], $user->company->pluck('id')->toArray()) && !auth()->user()->hasAnyRole('برنامه نویس|سوپرادمین'))
        )
            return ['ادمین موردنظر یافت نشد یا مربوط به شرکت انتخاب شده نمی باشد.'];

        $job->created_by = $user->id;
        $job->modified_by = $user->id;

        if (JobPost::where('name', $request['post'])->count() == 0) {
            JobPost::create(['name' => $request['post']]);
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        } else {
            $post_id = JobPost::where('name', $request['post'])->first()->id;
        }
        $job->post_id = $post_id;

        $job->save();

        #extra questions
        JobQuestions::where('job_id', $job->id)->delete();
        if (isset($request['questions'])) {
            foreach ($request['questions'] as $item) {
                $q = new JobQuestions();
                $q->question = $item['question'];
                $q->job_id = $job->id;
                $q->save();
            }
        }
        #end of extra questions
        $job->cities()->detach();
        foreach ($request['city_id'] as $item) {
            $job->cities()->attach($item);
        }

        Slider::where('model_name', 'Job')->where('model_id', $job->id)->delete();
        if (isset($request['images']) && !empty($request['images'])) {
            $images = explode(',', $request['images']);
            $images = array_filter($images);
            foreach ($images as $image) {
                $img = new Slider();
                $img->model_name = 'Job';
                $img->model_id = $job->id;
                $img->url = $image;
                $img->save();
            }
        }

        $job->job_general_merites()->detach();
        $job->job_professional_merites()->detach();

        # start of job_general_merites
        $general_skill = $request['general_skill'];
        foreach ($general_skill as $item) {

            $merit = JobGeneralMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobGeneralMerites::create(['name' => $item['name']]);
                $merit = JobGeneralMerites::where('name', $item['name'])->first();
            }
            $job->job_general_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites


        # start of job_general_merites
        $special_skill = $request['special_skill'];
        foreach ($special_skill as $item) {
            $merit = JobProfessionalMerites::where(DB::raw('replace(name, " ", "")'), str_replace(' ', '', $item['name']))->first();
            if (!$merit) {
                JobProfessionalMerites::create(['name' => $item['name']]);
                $merit = JobProfessionalMerites::where('name', $item['name'])->first();
            }
            $job->job_professional_merites()->attach([$merit->id => ['value' => $item['value']]]);
        }
        # end of job_general_merites

        return $job;
    }

    public function get_confirmed_users()
    {

        $rules = array(
            'job_id' => 'required|integer|exists:jobs,id'
        );


        $validator = Validator::make(request()->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }

        $applies = \HR\Apply
            ::leftjoin('users', 'applies.user_id', '=', 'users.id')
            ->leftjoin('resumes', 'resumes.user_id', '=', 'users.id')
            ->leftjoin('user_profiles', 'user_profiles.user_id', '=', 'users.id')
            ->leftjoin('provinces', 'provinces.id', '=', 'user_profiles.province_id')
            ->leftjoin('cities', 'cities.id', '=', 'user_profiles.city_id')
            ->leftjoin('resume_educational_details', 'resume_educational_details.resume_id', '=', 'resumes.id')
            ->select('users.id as user_id',
                'applies.id as apply_id',
                'applies.created_at as apply_date',
                'users.first_name',
                'users.last_name',
                'users.mobile as mobile',
                'user_profiles.home_phone as home_phone',
                'user_profiles.neighborhood as district',
                'provinces.name as province_name',
                'cities.name as city_name',
                'user_profiles.born_date as born_date',
                'user_profiles.national_code as national_code',
                'resume_educational_details.grade as level',
                'resume_educational_details.field',
                'resume_educational_details.institute'
            )
            ->where('applies.job_id', request('job_id'))
            ->where('applies.status', 4)
            ->groupBy('users.id')
            ->havingRaw('resume_educational_details.grade = MAX(resume_educational_details.grade)')
            ->get();
        foreach ($applies as $apply) {
            $apply->level = config('app.enum_last_degree')[$apply->level];
        }

        return $applies;
    }

    public function post_view_resume(Request $request)
    {
        $rules = array(
            'apply_id' => 'required|integer|exists:applies,id',
            'job_id' => 'required|integer|exists:jobs,id'
        );

        $validator = Validator::make(request()->all(), $rules);
        if ($validator->fails()) {
            return $validator->messages();
        }

        $apply = Apply::find($request['apply_id']);

        if ($apply->job_id != $request['job_id'])
            return ['درخواست ارسال شده برای این آگهی معتبر نمی باشد.'];

        if (!in_array($request['apply_id'],
            Apply::where('applies.job_id', request('job_id'))
                ->where('applies.status', 4)
                ->pluck('id')->toArray())
        )
            return ['درخواست انتخابی شما در لیست تایید نهایی این آگهی نمی باشد.'];


        $user = User::find($apply->user_id);
        $resume = Resume::find($user->resume->id);

        $view = View::make('site.resume.pdf', compact('resume'));

        $contents = $view->render();

        $pdf = SnappyPdf::loadHtml($contents)
            ->setPaper('A4')
            ->setOrientation('portrait')
            ->setOption('margin-bottom', 30)
            ->setOption('dpi', 300)
            ->setOption('footer-html', 'https://people.golrang.com/resume/footer.html');

        return $pdf->stream('result.pdf');

    }

    public function get_reject_reasons()
    {
        return RejectReasons::all(['id', 'reason']);
    }

    public function getUserHistory(Request $request)
    {
        $mobile = $request['mobile'];
        $detail = $request['detail'];
        //$user_profile = UserProfile::where('user_id',$user_id)->first();
        $userid = User::where('mobile',$mobile)->first()->id;
//die(json_encode($userid));
        if($detail == "false") {
         $data = collect(User::with(array(
             'applies' => function ($query) {
                 $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
             },
             'applies.job' => function ($query) {
                 $query->select('id','ItemId', 'post_id');
             },

             'profile' => function ($query) {
             $query->select('user_id', 'national_code');
         },
             'resume.educational_details',
             'resume.work_experience',
             'applies.job.post'=> function ($query) {
             $query->select('id','name','data_serial_number');
         }
         ))->where('id', $userid)->get())->map(function ($value, $key) {
             $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;
             $value['cover']  = 'https://people.golrang.com/' . $value['cover'];
             $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
             if ($value['cv'] == '')
                 $value['cv'] = '';
             else
                 $value['cv'] = 'https://people.golrang.com/' . $value['cv'];
             return $value;
         });
        }
         else if($detail == "true"){
             $data = collect(User::with(array(
                 'applies' => function ($query) {
                     $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
                 },
                 'profile' => function ($query) {
                 $query->select('user_id', 'national_code');
             },
                 'resume.educational_details',
                 'resume.work_experience',

                 'applies.job.post'))->where('id', 108738)->get())->map(function ($value, $key) {
                 $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;

                 $value['cover'] = 'https://people.golrang.com/' . $value['cover'];
                 $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
                 $value['file_content'] = json_encode(file_get_contents('https://people.golrang.com/adpanel/cv/'. $value['id'].'/show.pdf'));
                 $value['file_type'] = 'pdf';

                 return $value;
             });
         }
         return new JsonResponse($data->all());
    }
    public static function getUserApply($userid)
    {

             $data = collect(User::with(array(
                 'applies' => function ($query) {
                     $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
                 },
                 'profile' => function ($query) {
                 $query->select('user_id', 'national_code');
             },
                 'resume.educational_details',
                 'resume.work_experience',


                 'applies.job.post'))->where('id', $userid)->get())->map(function ($value, $key) {
                 $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;

                 $value['cover'] = 'https://people.golrang.com/' . $value['cover'];
                 $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
                 $value['file_content'] = file_get_contents('https://people.golrang.com/cv/'. $value['id'].'/show.pdf');
                 $value['resume_url'] = 'https://people.golrang.com/cv/'. $value['id'].'/show.pdf';
                 $value['file_type'] = 'pdf';

                 return $value;
             });

         return new JsonResponse($data->all());
    }

    public function testGetUserHistory(Request $request)
    {
        $mobile = $request['mobile'];
        $detail = $request['detail'];
        //$user_profile = UserProfile::where('user_id',$user_id)->first();
        $userid = User::where('mobile',$mobile)->first()->id;
        $resumeid = Resume::where('user_id',$userid)->first()->id;
//die(json_encode($userid));
        if($detail == "false") {
         $data = collect(User::with(array(
             'applies' => function ($query) {
                 $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
             },
             'applies.job' => function ($query) {
                 $query->select('id','ItemId', 'post_id');
             },

             'profile' => function ($query) {
             $query->select('user_id', 'national_code');
         },
             'resume.educational_details'=> function ($query) use($resumeid) {
                 $query->select('*')->from('resume_educational_details')
                     ->where('grade',DB::raw("(select max(grade) from resume_educational_details where resume_id=".$resumeid.")"))->get();


/*                     DB::statement( from resume_educational_details yt where grade = (select max(grade) from resume_educational_details st where resume_id=75135) and resume_id=75135'));*/
             },

             'applies.job.post'=> function ($query) {
             $query->select('id','name','data_serial_number');
         }
         ))->where('id', $userid)->get())->map(function ($value, $key) {
             $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;
             $value['cover']  = 'https://people.golrang.com/' . $value['cover'];
             $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
             if ($value['cv'] == '')
                 $value['cv'] = '';
             else
                 $value['cv'] = 'https://people.golrang.com/' . $value['cv'];
             return $value;
         });
        }
         else if($detail == "true"){
             $data = collect(User::with(array('profile' => function ($query) {
                 $query->select('user_id', 'national_code');
             },
                 'applies' => function ($query) {
                     $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
                 },

                 'applies.job.post'))->where('id', 108738)->get())->map(function ($value, $key) {
                 $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;

                 $value['cover'] = 'https://people.golrang.com/' . $value['cover'];
                 $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
                 if ($value['cv'] == '')
                     $value['cv'] = '';
                 else
                     $value['cv'] = 'https://people.golrang.com/' . $value['cv'];
                 return $value;
             });
         }
         return new JsonResponse($data->all());
    }
    public function test1($userid)
    {
       /// $mobile = $request['mobile'];
       /// $detail = $request['detail'];
        //$user_profile = UserProfile::where('user_id',$user_id)->first();
       // $userid = User::where('mobile',$mobile)->first()->id;
        $resumeid = Resume::where('user_id',$userid)->first()->id;
//die(json_encode($userid));

             $data = collect(User::with(array('profile' => function ($query) {
                 $query->select('user_id', 'national_code');
             },
                 'applies' => function ($query) {
                     $query->select('user_id','id as people_applicate_id','job_id','status','reject_reason','reject_description');
                 },

                 'applies.job.post'))->where('id', $userid)->get())->map(function ($value, $key) {
                 $value['IsBlackList'] = (\GuzzleHttp\json_decode(file_get_contents("http://172.31.2.18/PersonnelStatus/GetState?MeliCode=".$value['national_code'])))->Status;

                 $value['cover'] = 'https://people.golrang.com/' . $value['cover'];
                 $value['avatar'] = 'https://people.golrang.com/' . $value['avatar'];
                 if ($value['cv'] == '')
                     $value['cv'] = '';
                 else
                     $value['cv'] = 'https://people.golrang.com/' . $value['cv'];
                 return $value;
             });

         return new JsonResponse($data->all());
    }

    public function testmwebservice()
    {
        $res = ($this->test1(108738));
        $user = $res->getData()[0];
        $first_name = $user->first_name;
        $last_name  = $user->last_name;
        $email      = $user->email;
        $mobile     = $user->mobile;
        $bio        = $user->bio;
        $created_at =  "2020-04-17T09:46:28.531Z";
        $updated_at = "2020-04-17T09:46:28.531Z";
        $avatar     = $user->avatar;
        $cover      = $user->cover;
        $cv         = '';
        $isBlackList         = $user->isBlackList;
        $people_user_id      = $user->id;
        $national_code       = $user->profile->national_code;
        $people_applicant_id = 1000;
        $file_content        = $user->cv;
        $file_type           =  "pdf";


        $data = json_encode(array(
            "first_name"  => $first_name,
            "last_name" => $last_name,
            "email"     =>$email,
            "mobile"    =>$mobile,
            "bio"=>$bio,
            "created_at"=>$created_at,
            "updated_at"=>$updated_at,
            "avatar"=>$avatar,
            "cover"=>$cover,
            "cv"=>$cv,
            "isBlackList"=>0,
            "people_user_id"=>$people_user_id,
            "national_code"=>$national_code,
            "people_applicant_id"=>$people_applicant_id,
            "file_type"=>$file_type,
            "file_content"=>$file_content

        ));

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "http://172.31.0.156:8000/api/Applicant/InsertPeopleApplicantAsync",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS =>$data,
            CURLOPT_HTTPHEADER => array(
                "authorization: bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIwMWYwZTRlOS1mNDhhLTRlOGItYjM4Yi1iMWNiM2M0ZTI5NTMiLCJpc3MiOiJBbnkiLCJpYXQiOjE1ODcxMTQ4ODIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWVpZGVudGlmaWVyIjoiMTQ3IiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZSI6IlBlb3BsZSIsIkRpc3BsYXlOYW1lIjoiUGVvcGxlIiwidXNlcklkIjoiMTQ3IiwiY29tcGFueUlkIjoiNDQ1IiwibGFuZ1R5cGVDb2RlIjoiMSIsImJyYW5jaElkIjoiNDQ1IiwibmJmIjoxNTg3MTE0ODgyLCJleHAiOjE1OTkxMTQ4ODIsImF1ZCI6IkFueSJ9.YsN5KKj4cCDDGdmpddFlajvu0cTGrnPkA8oM10GUQCo",
                "Content-Type: application/json"
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        die(json_encode($response));

        echo $first_name;
        echo $last_name;
        echo $mobile;echo $bio;echo $email;echo $avatar;echo $cover;echo $cv;$isBlackList;echo $national_code;
    }
    
        public function generateToken()
    {
        $token = openssl_random_pseudo_bytes(16);
        $token = bin2hex($token);

        $data = array('token' => $token);
            DB::table('tokens')->insert($data);

        //$token = collect(array('token'=>$token));
        return $token;
    }
    public function apiGetOnlineCv($national_code,$token)
    {
        $user_id = UserProfile::where('national_code',$national_code)->first()->user_id;
        $resume_id = Resume::where('user_id',$user_id)->first()->id;
        $token_expire = DB::select('select * from tokens where token="'.$token.'" limit 1');
         if(count($token_expire) > 0 && $token_expire[0]->expire == 0)
          {
              if($resume_id > 0){
             
              header("Content-type:application/pdf");
              return \Redirect::route('api.resumes.show', ['resume'=>$resume_id,'token'=>$token]);
              }
               else{

              return view('admin.api.404');
               }
              

          }

          else{
            abort(403);
        }
     




    }
    public function apiGetUploadedCv($id)
    {
        header("Content-type:application/pdf");

        if(\Illuminate\Support\Facades\Storage::disk('resume')->exists('cv/'.myFuncs::spilit_string($id).'/resume.pdf'))
        {
            echo Storage::disk('resume')->get('cv/'.myFuncs::spilit_string($id).'/resume.pdf');
        }
        else
        {
            abort(404);
        }
    }
}