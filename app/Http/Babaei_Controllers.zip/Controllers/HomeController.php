<?php

namespace HR\Http\Controllers;

use HR\Company;
use HR\Content;
use HR\ContentCategory;
use HR\Job;
use HR\JobDepartment;
use HR\OthersSay;
use HR\Province;
use HR\Setting\FirstContent;
use HR\Setting\FirstPageFooter;
use HR\Setting\FirstPageSlider;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function __construct()
    {
        ini_set('memory_limit', '-1');
    }
    public function index()
    {
        
        $first_content = FirstContent::all()->first();
        $sliders = FirstPageSlider::where('status',1)->get();
        $footer = FirstPageFooter::all()->first();

        $jobs = Job::where('status',1)
            ->where('approved',1)
            ->where('expire_date','>=',Carbon::now()->toDateTimeString())->limit(16)->get();

        $jobs_ids = $jobs->pluck('id')->toArray();
        $job_provinces =  DB::table('jobs')
            ->select('provinces.name')
            ->leftjoin('job_has_cities','jobs.id', '=', 'job_has_cities.job_id')
            ->leftjoin('cities','job_has_cities.city_id', '=', 'cities.id')
            ->leftjoin('provinces','provinces.id', '=', 'cities.province_id')
            ->where('provinces.name','!=',null)
            ->wherein('jobs.id',$jobs_ids)
            ->groupBy('provinces.name')->pluck('provinces.name')->toArray();

        $job_companies = DB::table('jobs')
            ->select('companies.name')
            ->leftjoin('companies','jobs.company_id', '=', 'companies.id')
            ->wherein('jobs.id',$jobs_ids)
            ->groupBy('companies.name')->pluck('companies.name')->toArray();

        $job_departments = DB::table('jobs')
            ->select('job_departments.name')
            ->leftjoin('job_departments','jobs.department_id', '=', 'job_departments.id')
            ->wherein('jobs.id',$jobs_ids)
            ->groupBy('job_departments.name')->pluck('job_departments.name')->toArray();
            
        if(ContentCategory::where('title','رویدادها')->first()->status == 2)
            return null;
    
        if(\Request::route()->getName() == 'site.events.educational.index') {
            $CategoryId = array(14);
            $edu = 1;
        }
        else {
            $CategoryId = array(9, 10, 11, 14);
            $edu = 0;
        }
        
        $contents = Content::whereIn('cat_id',$CategoryId)
        ->orderByDesc('created_at')
        ->where(function($q) {
            $q->where('start_publish','<=',Carbon::now()->toDateTimeString())
                ->orWhere('start_publish', null);
        })
        ->where(function($q) {
            $q->where('end_publish','>=',Carbon::now()->toDateTimeString())
                ->orWhere('end_publish', null);
        })
        ->where('approved','1')
        ->where('status','1')
        ->where('pin_status','0')
        ->orderBy('created_at','desc')
        ->limit(10)
        ->get();;
        

            

        return view('site.pages.home',compact(['jobs','first_content','sliders','footer','job_provinces','job_companies','job_departments','contents']));
    }
}
