<?php


namespace HR\Http\Controllers;


use HR\Company;
use HR\SupportTicketReply;
use http\Env\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;


class SupportTicketReplyController extends Controller
{
}