<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>رزومه یافت نشد</title>
    <style>
        div {
            text-align:center;
            padding:30px;
            margin:auto;
            font:10pt Tahoma;
            font-weight: bold;
            background: #1F1F1F;
            color:white;
            width:80%;
            border-radius:5px;
        }
    </style>
</head>

<body>
<div>
    <div>رزومه یافت نشد</div>
</div>

</body>
</html>