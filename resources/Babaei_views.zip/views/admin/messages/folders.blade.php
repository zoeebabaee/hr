<ul class="folder-list m-b-md" style="padding: 0">
    <li><a href="{{route('messages.inbox')}}"> <i class="fa fa-inbox "></i> دریافت ها

        </a></li>
    <li><a href="{{route('messages.sent')}}"> <i class="fa fa-envelope-o"></i> ارسال ها</a></li>
    <li><a href="{{route('messages.trash')}}"> <i class="fa fa-trash-o"></i> حذف شده ها
        </a></li>
</ul>