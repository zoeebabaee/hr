<div id="pagepiling" class="cd-main-content" >
    
    <div class="hidden-xs hidden-sm section" id="section1" @yield('first_content_image') >
        <div class="intro">
            <div class="container">

                @yield('first_content')

            </div>
        </div>
    </div>