<div class="section" id="section4" style="background: url(/site/default/img/bg-events.jpg) no-repeat top center/cover;">
    @include('site.modules.events')
</div>
