@extends('layout.site.default.global.main')

@section('meta')
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Golrang Human Resource">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Golrang System">
@endsection

@section('custom_css')
    <link rel="stylesheet" href="/site/default/css/simple-line-icons.css">
@endsection

@section('title')
    سامانه منابع انسانی :: سوالات متداول
@endsection

@section('content')

        <div class="cd-main-content cd-inner-content" style="min-height: auto">
            <div class="clearfix wrapper-breadcrumb">
                <div class="p-breadcrumbs">
                    <ul class="page-breadcrumbs">
                        <li>
                            <a href="index.html">صفحه اصلی</a>
                        </li>
                        <li><i class="fa fa-angle-left"></i></li>
                        <li class="c-state_active">
                            سوالات متداول
                        </li>
                    </ul>
                </div>
            </div>
            <div class="top-innerpage"
                 style="background:url('/site/default/img/banner.jpg') no-repeat top center/cover;">
                <div class="container"><h1 class="wow animated fadeInUp"> سوالات متداول </h1></div>
            </div>
            <div class="clearfix container inner-content">
                <div class="col-xs-12 wrap-content">
                    <div class="col-md-12 col-sm-12 col-xs-12 left-jobs no-padd-xs no-padd-l">
                        <div class="panel-group" id="accordion1">
                            @foreach($faqs as $faq)
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1"
                                               href="#collapse{{$faq->id}}">
                                                {{strip_tags($faq->question)}}
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapse{{$faq->id}}" class="panel-collapse collapse {{$loop->index==0?'in':''}}">
                                        <div class="panel-body fag-content">
                                            {!! $faq->answer !!}
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

@section('script')

@endsection